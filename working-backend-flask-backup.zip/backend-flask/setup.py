from setuptools import setup, find_packages
 
setup(name = "backend-flask", packages = find_packages())